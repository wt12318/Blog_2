---
title: 支持向量机(SVM)-理论
author: wutao
date: 2021-06-19 10:00:00
slug: math
categories:
  - 机器学习
  - 数学
index_img: img/svm.png
---

支持向量机理论，参考李航《统计学习方法》
<!-- more -->

![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_8.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_1.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_2.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_3.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_4.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_5.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_6.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_7.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_8.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_9.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_10.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_18-06-07_11.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_0.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_1.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_2.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_3.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_4.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_5.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_6.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-06-19_17-31-30_7.jpg)

