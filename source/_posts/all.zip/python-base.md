---
title: Python 基础
date: 2021-01-16 16:51:08
tags: 编程
index_img: img/python.jpg
categories:
  - python
---

![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/image-20210118230926897.png)

![py2](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/py2.png)

![py33](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/py33.png)

![py44](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/py44.png)
