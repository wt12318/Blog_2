---
title: 拉格朗日对偶性
author: wutao
date: 2021-03-28 17:03:30
slug: lagrange_duality
categories:
  - 机器学习
  - 数学
index_img: img/lage.png
---

![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_17-38-13.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_17-40-35_1.jpg)
![](https://picgo-wutao.oss-cn-shanghai.aliyuncs.com/img/2021-03-28_17-40-35_0.jpg)

参考：李航《统计学习方法》